# Metadados de Ficheiros

## Fotografia Campus Braga
- **Data de Criação**: 2025-03-10T08:30:00Z
- **Data de Submissão**: 2025-05-01T10:00:00Z
- **Produtor**: jose.matos
- **Publicador**: univ-minho
- **Tipo**: Imagem
- **Tags**: Institucional, Campus

## Relatório Anual de Atividades
- **Data de Criação**: 2024-12-15T14:00:00Z
- **Data de Submissão**: 2025-05-01T12:45:00Z
- **Produtor**: maria.silva
- **Publicador**: univ-minho
- **Tipo**: Documento
- **Tags**: Académico, Relatório

## Resultados Inquérito Satisfação
- **Data de Criação**: 2025-01-20T09:00:00Z
- **Data de Submissão**: 2025-05-01T13:00:00Z
- **Produtor**: departamento.ti
- **Publicador**: univ-minho
- **Tipo**: Dados
- **Tags**: Estatística, Inquérito

## Audio Teste
- **Data de Criação**: 2025-02-05T11:15:00Z
- **Data de Submissão**: 2025-05-01T13:13:08.656Z
- **Produtor**: teste
- **Publicador**: teste
- **Tipo**: Áudio
- **Tags**: Académico/Resultado Académico

## Vídeo Apresentação Projeto Final
- **Data de Criação**: 2025-04-01T16:00:00Z
- **Data de Submissão**: 2025-05-01T14:30:00Z
- **Produtor**: carlos.pereira
- **Publicador**: univ-minho
- **Tipo**: Vídeo
- **Tags**: Académico, Projeto Final

